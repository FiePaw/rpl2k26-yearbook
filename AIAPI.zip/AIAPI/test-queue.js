/**
 * Test Queue Management Endpoints
 * Mengecek status antrian request
 */

const AIScraperClient = require('./client');

async function testQueue() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Queue Management             ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    // Test Queue Status
    console.log('1️⃣  Getting Queue Status...\n');
    const status = await client.getQueueStatus();

    if (status.error) {
      console.error('❌ Error:', status.error);
    } else {
      console.log('✅ Queue Status:');
      console.log(JSON.stringify(status, null, 2));
    }

    console.log('\n───────────────────────────────────────\n');

    // Test Queue Info
    console.log('2️⃣  Getting Queue Info...\n');
    const info = await client.getQueueInfo();

    if (info.error) {
      console.error('❌ Error:', info.error);
    } else {
      console.log('✅ Queue Info:');
      console.log(JSON.stringify(info, null, 2));
    }

    console.log('\n───────────────────────────────────────\n');

    // Test Queue Stats
    console.log('3️⃣  Getting Queue Statistics...\n');
    const stats = await client.getQueueStats();

    if (stats.error) {
      console.error('❌ Error:', stats.error);
    } else {
      console.log('✅ Queue Statistics:');
      console.log(JSON.stringify(stats, null, 2));
    }
  } catch (error) {
    console.error('❌ Request failed:', error.message);
  }
}

testQueue();
