/**
 * Test Qwen Query Endpoint
 * Mengquery Qwen AI dengan prompt
 */

const AIScraperClient = require('./client');

async function testQwen() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Qwen Query Endpoint          ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    const prompt = 'berikan saya lirik lagu dengan detik nya contoh 00:00 lirik lagu slow dancing in the dark - joji';

    console.log(`📡 Query: "${prompt}"\n`);
    console.log('⏳ Waiting for response...\n');

    const response = await client.queryQwen(prompt, 'new');

    if (response.error) {
      console.error('❌ Error:', response.error);
      return;
    }

    if (!response.success) {
      console.error('❌ Request failed');
      console.log(JSON.stringify(response, null, 2));
      return;
    }

    console.log('✅ Success\n');
    console.log('📋 Response Details:');
    console.log('═══════════════════════════════════════');
    console.log(`Service: ${response.scriptName}`);
    console.log(`Mode: ${response.mode}`);
    console.log(`Timestamp: ${response.timestamp}\n`);

    if (response.result) {
      console.log('📝 AI Response:');
      console.log('───────────────────────────────────────');
      console.log(JSON.stringify(response.result, null, 2));
    } else {
      console.log('📝 Raw Output:');
      console.log('───────────────────────────────────────');
      console.log(response.rawOutput);
    }
  } catch (error) {
    console.error('❌ Exception:', error.message);
  }
}

testQwen();
