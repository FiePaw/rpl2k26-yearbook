/**
 * Test Health Check Endpoint
 * Mengecek status server dan service yang tersedia
 */

const AIScraperClient = require('./client');

async function testHealth() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Health Check Endpoint        ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    console.log('📡 Mengirim request ke /api/health...\n');
    const response = await client.health();

    if (response.error) {
      console.error('❌ Error:', response.error);
      return;
    }

    console.log('✅ Server Status: OK\n');
    console.log('📋 Response:');
    console.log(JSON.stringify(response, null, 2));

    console.log('\n✨ Available Services:');
    response.availableServices?.forEach(service => {
      console.log(`  ✓ ${service}`);
    });
  } catch (error) {
    console.error('❌ Request failed:', error.message);
  }
}

testHealth();
