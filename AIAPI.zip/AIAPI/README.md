# 🚀 AI Scraper Test Client - ForTes

Folder ini berisi kode JavaScript untuk menguji API Scraper dari device lain menggunakan Node.js.

## 📋 File-file yang Tersedia

### Core Files

| File | Deskripsi |
|------|-----------|
| `package.json` | NPM configuration dan script commands |
| `client.js` | Main client class untuk berkomunikasi dengan API |

### Test Files

| File | Deskripsi | Command |
|------|-----------|---------|
| `test-health.js` | Test health check endpoint | `npm run test:health` |
| `test-services.js` | Test get services endpoint | `npm run test:services` |
| `test-openai.js` | Test OpenAI query | `npm run test:openai` |
| `test-grok.js` | Test Grok query | `npm run test:grok` |
| `test-qwen.js` | Test Qwen query | `npm run test:qwen` |
| `test-query-all.js` | Test query all services parallel | `npm run test:all` |
| `test-queue.js` | Test queue management | `npm run test:queue` |
| `example.js` | Complete example usage | `npm run example` |

---

## 🔧 Setup

### 1. Copy Folder ke Device Lain

Salin folder `ForTes` ke device lain yang ingin menjalankan test.

### 2. Install Dependencies (jika diperlukan)

```bash
npm install
```

> **Catatan:** Saat ini tidak ada dependencies eksternal, semua menggunakan built-in Node.js API.

### 3. Konfigurasi Server URL

**Di device yang menjalankan server:**

Ubah [server.js](../server.js) untuk listen pada semua interface (0.0.0.0):

```javascript
// Ganti baris listen dengan:
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Server running on http://0.0.0.0:${PORT}`);
});
```

**Di client (ForTes):**

Ubah base URL di semua test files atau di `client.js`:

```javascript
// Ganti:
new AIScraperClient('http://16.79.192.14:5500')

// Dengan IP address server Anda:
new AIScraperClient('http://192.168.1.100:5500')
```

### 4. Dapatkan IP Address Server

**Windows:**
```bash
ipconfig
# Cari IPv4 Address
```

**Linux/Mac:**
```bash
hostname -I
```

### 5. Setup Firewall

**Windows:**
```bash
netsh advfirewall firewall add rule name="Allow Port 5500" dir=in action=allow protocol=tcp localport=5500
```

---

## ▶️ Cara Menjalankan

### Test Health Check

```bash
npm run test:health
```

Output:
```
╔═══════════════════════════════════════╗
║  Testing Health Check Endpoint        ║
╚═══════════════════════════════════════╝

✅ Server Status: OK

📋 Response:
{
  "status": "ok",
  "service": "AI Scraper Server",
  "version": "1.0.0",
  "timestamp": "2026-02-22T10:30:45.123Z",
  "availableServices": [
    "openai",
    "grok",
    "qwen"
  ]
}

✨ Available Services:
  ✓ openai
  ✓ grok
  ✓ qwen
```

### Test Get Services

```bash
npm run test:services
```

### Test OpenAI Query

```bash
npm run test:openai
```

### Test Grok Query

```bash
npm run test:grok
```

### Test Qwen Query

```bash
npm run test:qwen
```

### Test Query All Services (Parallel)

```bash
npm run test:all
```

### Test Queue Management

```bash
npm run test:queue
```

### Run Complete Example

```bash
npm run example
```

Ini akan menjalankan:
1. Health check
2. Get services
3. Query OpenAI
4. Query Grok
5. Check queue status

---

## 📖 Cara Menggunakan Client Class

### Basic Usage

```javascript
const AIScraperClient = require('./client');

const client = new AIScraperClient('http://16.79.192.14:5500');

// Check health
const health = await client.health();
console.log(health);

// Query a service
const result = await client.queryDeepSeek('Apa itu AI?');
console.log(result);
```

### Query Different Services

```javascript
// OpenAI
const openai = await client.queryOpenAI('Your prompt', 'new');

// Grok
const grok = await client.queryGrok('Your prompt', 'new');

// Qwen
const qwen = await client.queryQwen('Your prompt', 'new');

// All services in parallel
const all = await client.queryAll('Your prompt', 'new');
```

### Queue Management

```javascript
// Get queue status
const status = await client.getQueueStatus();
console.log(status);

// Get queue info
const info = await client.getQueueInfo();
console.log(info);

// Get queue statistics
const stats = await client.getQueueStats();
console.log(stats);
```

### Error Handling

```javascript
const result = await client.queryOpenAI('Your prompt');

if (result.error) {
  console.error('Error:', result.error);
} else if (result.success) {
  console.log('Success:', result.result);
}
```

---

## 🐛 Troubleshooting

### Server tidak merespons

❌ **Error:** `Cannot connect to server`

**Solusi:**
1. Pastikan server sedang running: `node server.js`
2. Check firewall settings
3. Verify IP address dan port yang benar
4. Test dengan ping ke server: `ping 16.79.192.14`

### Connection Refused

❌ **Error:** `ECONNREFUSED`

**Solusi:**
1. Server belum start
2. IP address salah
3. Port 5500 diblokir firewall
4. Server listening hanya pada localhost (ubah ke 0.0.0.0)

### Timeout

❌ **Error:** `timeout`

**Solusi:**
1. Check `/api/queue/status` untuk lihat antrian
2. Tunggu request sebelumnya selesai
3. Increase timeout value di client.js
4. Check resource availability di server

### Empty Response

❌ **Error:** Response kosong atau undefined

**Solusi:**
1. Pastikan prompt tidak kosong
2. Check server logs untuk error details
3. Verify network connectivity
4. Coba test dengan prompt yang lebih sederhana

---

## 📝 Contoh Complete Script

```javascript
const AIScraperClient = require('./client');

async function main() {
  const client = new AIScraperClient('http://16.79.192.14:5500');

  try {
    // 1. Check health
    console.log('Checking server health...');
    const health = await client.health();
    if (health.error) {
      console.error('Server error:', health.error);
      return;
    }

    // 2. Get services
    console.log('Getting available services...');
    const services = await client.getServices();
    console.log('Services:', services.services.map(s => s.name));

    // 3. Query multiple services
    const prompts = [
      'Apa itu AI?',
      'Jelaskan machine learning',
      'Apa itu neural networks?'
    ];

    for (const prompt of prompts) {
      console.log(`\nQuerying: ${prompt}`);
      const result = await client.queryDeepSeek(prompt);
      if (result.success) {
        console.log('Result:', result.result);
      } else {
        console.error('Error:', result.error);
      }
    }
  } catch (error) {
    console.error('Fatal error:', error.message);
  }
}

main();
```

---

## 🔗 Resources

- [Full API Documentation](../API_DOCUMENTATION.md)
- [Server Source Code](../server.js)
- [Queue Manager](../queue-manager.js)

---

## 📞 Support

Jika ada masalah:

1. Check output dari test files
2. Lihat server logs (di terminal server)
3. Verify network connectivity
4. Check firewall settings
5. Ensure server.js berjalan di device server

---

**Last Updated:** February 22, 2026  
**Client Version:** 1.0.0
