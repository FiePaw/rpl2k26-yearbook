/**
 * Example Usage - Complete Demonstration
 * Menunjukkan cara menggunakan AI Scraper Client secara lengkap
 */

const AIScraperClient = require('./client');

async function runExample() {
  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║     AI Scraper Client - Complete Example         ║');
  console.log('╚══════════════════════════════════════════════════╝\n');

  // Ubah IP address sesuai server Anda
  const client = new AIScraperClient('http://16.79.192.14:5500');

  try {
    // Step 1: Check health
    console.log('\n📡 STEP 1: Checking Server Health\n');
    console.log('───────────────────────────────────────────────\n');

    const health = await client.health();
    if (health.error) {
      console.error('❌ Server tidak merespons:', health.error);
      console.log('\n⚠️  Pastikan:');
      console.log('  1. Server sudah running (node server.js)');
      console.log('  2. IP address sudah benar: 16.79.192.14');
      console.log('  3. Port 5500 tidak diblokir firewall\n');
      return;
    }

    console.log(`✅ Server Status: ${health.status}`);
    console.log(`✅ Service: ${health.service}`);
    console.log(`✅ Version: ${health.version}`);
    console.log(`✅ Available Services: ${health.availableServices.join(', ')}\n`);

    // Step 2: Get available services
    console.log('\n📚 STEP 2: Getting Available Services\n');
    console.log('───────────────────────────────────────────────\n');

    const services = await client.getServices();
    console.log('Available Services:');
    services.services?.forEach((svc) => {
      console.log(
        `  ✓ ${svc.name.padEnd(12)} | ${svc.status === 'available' ? '✅' : '❌'} ${svc.status}`
      );
    });

    // Step 3: Query individual service
    console.log('\n\n🔍 STEP 3: Querying Individual Service (OpenAI)\n');
    console.log('───────────────────────────────────────────────\n');

    const prompt1 = 'Apa itu Artificial Intelligence? (jawab dalam 3 baris)';
    console.log(`📝 Prompt: "${prompt1}"\n`);
    console.log('⏳ Processing...\n');

    const openaiResult = await client.queryOpenAI(prompt1, 'new');

    if (openaiResult.error) {
      console.error('❌ Error:', openaiResult.error);
    } else if (openaiResult.success) {
      console.log('✅ OpenAI Response:');
      console.log('─────────────────────────────────────────────');
      if (openaiResult.result) {
        console.log(JSON.stringify(openaiResult.result, null, 2));
      } else {
        console.log(openaiResult.rawOutput);
      }
    }

    // Step 4: Query another service
    console.log('\n\n🔍 STEP 4: Querying Another Service (Grok)\n');
    console.log('───────────────────────────────────────────────\n');

    const prompt2 = 'Berikan tips belajar programming untuk pemula';
    console.log(`📝 Prompt: "${prompt2}"\n`);
    console.log('⏳ Processing...\n');

    const grokResult = await client.queryGrok(prompt2, 'new');

    if (grokResult.error) {
      console.error('❌ Error:', grokResult.error);
    } else if (grokResult.success) {
      console.log('✅ Grok Response:');
      console.log('─────────────────────────────────────────────');
      if (grokResult.result) {
        console.log(JSON.stringify(grokResult.result, null, 2));
      } else {
        console.log(grokResult.rawOutput);
      }
    }

    // Step 5: Query Qwen service
    console.log('\n\n🔍 STEP 5: Querying Qwen Service\n');
    console.log('───────────────────────────────────────────────\n');

    const prompt3 = 'Jelaskan konsep machine learning dengan bahasa sederhana';
    console.log(`📝 Prompt: "${prompt3}"\n`);
    console.log('⏳ Processing...\n');

    const qwenResult = await client.queryQwen(prompt3, 'new');

    if (qwenResult.error) {
      console.error('❌ Error:', qwenResult.error);
    } else if (qwenResult.success) {
      console.log('✅ Qwen Response:');
      console.log('─────────────────────────────────────────────');
      if (qwenResult.result) {
        console.log(JSON.stringify(qwenResult.result, null, 2));
      } else {
        console.log(qwenResult.rawOutput);
      }
    }


    // Step 6: Check queue status
    console.log('\n\n📊 STEP 6: Checking Queue Status\n');
    console.log('───────────────────────────────────────────────\n');

    const queueStatus = await client.getQueueStatus();
    console.log('Queue Status:');
    console.log(JSON.stringify(queueStatus, null, 2));

    console.log('\n✨ Example completed successfully!\n');
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

// Run example
runExample();
