/**
 * Test Get Services Endpoint
 * Mendapatkan daftar service yang tersedia
 */

const AIScraperClient = require('./client');

async function testServices() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Get Services Endpoint        ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    console.log('📡 Mengirim request ke /api/services...\n');
    const response = await client.getServices();

    if (response.error) {
      console.error('❌ Error:', response.error);
      return;
    }

    console.log('✅ Success\n');
    console.log('📋 Available Services:');
    console.log('═══════════════════════════════════════\n');

    response.services?.forEach((service, index) => {
      console.log(`${index + 1}. ${service.name.toUpperCase()}`);
      console.log(`   Endpoint: ${service.endpoint}`);
      console.log(`   Description: ${service.description}`);
      console.log(`   Status: ${service.status === 'available' ? '✅' : '❌'} ${service.status}`);
      console.log();
    });

    console.log(`Timestamp: ${response.timestamp}`);
  } catch (error) {
    console.error('❌ Request failed:', error.message);
  }
}

testServices();
