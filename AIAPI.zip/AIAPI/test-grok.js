/**
 * Test Grok Query Endpoint
 * Mengquery Grok AI dengan prompt
 */

const AIScraperClient = require('./client');

async function testGrok() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Grok Query Endpoint          ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    const prompt = 'Apa perbedaan antara Artificial Intelligence dan Machine Learning?';

    console.log(`📡 Query: "${prompt}"\n`);
    console.log('⏳ Waiting for response...\n');

    const response = await client.queryGrok(prompt, 'new');

    if (response.error) {
      console.error('❌ Error:', response.error);
      return;
    }

    if (!response.success) {
      console.error('❌ Request failed');
      console.log(JSON.stringify(response, null, 2));
      return;
    }

    console.log('✅ Success\n');
    console.log('📋 Response Details:');
    console.log('═══════════════════════════════════════');
    console.log(`Service: ${response.scriptName}`);
    console.log(`Mode: ${response.mode}`);
    console.log(`Timestamp: ${response.timestamp}\n`);

    if (response.result) {
      console.log('📝 AI Response:');
      console.log('───────────────────────────────────────');
      console.log(JSON.stringify(response.result, null, 2));
    } else {
      console.log('📝 Raw Output:');
      console.log('───────────────────────────────────────');
      console.log(response.rawOutput);
    }
  } catch (error) {
    console.error('❌ Request failed:', error.message);
  }
}

testGrok();
