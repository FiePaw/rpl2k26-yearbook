/**
 * Test Query All Services Endpoint
 * Mengquery semua service AI secara bersamaan (parallel)
 */

const AIScraperClient = require('./client');

async function testQueryAll() {
  console.log('╔═══════════════════════════════════════╗');
  console.log('║  Testing Query All Services           ║');
  console.log('╚═══════════════════════════════════════╝\n');

  const client = new AIScraperClient();

  try {
    const prompt = 'Apa itu cloud computing dan keuntungannya?';

    console.log(`📡 Query: "${prompt}"\n`);
    console.log('⏳ Querying all services in parallel...\n');

    const response = await client.queryAll(prompt, 'new');

    if (response.error) {
      console.error('❌ Error:', response.error);
      return;
    }

    if (!response.success) {
      console.error('❌ Request failed');
      console.log(JSON.stringify(response, null, 2));
      return;
    }

    console.log('✅ All services queried successfully\n');
    console.log('📋 Summary:');
    console.log('═══════════════════════════════════════');
    console.log(`Timestamp: ${response.timestamp}\n`);

    // Display results for each service
    const services = ['openai', 'grok', 'qwen'];

    services.forEach((service) => {
      const result = response.results[service];
      console.log(`\n${service.toUpperCase()}:`);
      console.log('───────────────────────────────────────');

      if (result.error) {
        console.log(`❌ Error: ${result.error}`);
      } else if (result.success) {
        console.log('✅ Success');
        if (result.result) {
          console.log('Response:');
          console.log(JSON.stringify(result.result, null, 2));
        } else if (result.rawOutput) {
          console.log('Raw Output:');
          console.log(result.rawOutput.substring(0, 500) + '...');
        }
      }
    });
  } catch (error) {
    console.error('❌ Request failed:', error.message);
  }
}

testQueryAll();
